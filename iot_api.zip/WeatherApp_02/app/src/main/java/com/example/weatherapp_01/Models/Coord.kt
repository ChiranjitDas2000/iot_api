package com.example.weatherapp_01.Models

data class Coord(
    val lat: Double,
    val lon: Double
)