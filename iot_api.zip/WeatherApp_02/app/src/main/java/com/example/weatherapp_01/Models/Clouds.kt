package com.example.weatherapp_01.Models

data class Clouds(
    val all: Int
)