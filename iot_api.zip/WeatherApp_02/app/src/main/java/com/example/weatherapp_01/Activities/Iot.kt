
package com.example.weatherapp_01.Activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.weatherapp_01.R
import com.example.weatherapp_01.ThingSpeakResponse
import com.example.weatherapp_01.Utilites.ThingSpeakApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone


class iot : AppCompatActivity() {

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.thingspeak.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val thingSpeakApi = retrofit.create(ThingSpeakApi::class.java)
    private val refreshIntervalMillis = 15000L // 15 sec
    private val handler = Handler()
    private lateinit var webViewTemperature: WebView
    private lateinit var webViewHumidity: WebView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_iot)

        webViewTemperature = findViewById(R.id.webViewTemperature)
        webViewHumidity = findViewById(R.id.webViewHumidity)


        loadThingSpeakChartTemperature()
        loadThingSpeakChartHumidity()


        val buttonNavigate: Button = findViewById(R.id.buttonNavigate)

        buttonNavigate.setOnClickListener {
            val intent = Intent(this@iot, MainActivity::class.java)
            startActivity(intent)
        }
        val textViewTemperature = findViewById<TextView>(R.id.textViewTemperature)
        val textViewHumidity = findViewById<TextView>(R.id.textViewHumidity)
        val textViewCreatedAt = findViewById<TextView>(R.id.textViewCreatedAt)



        startAutoRefresh(textViewTemperature, textViewHumidity, textViewCreatedAt)
    }
    @SuppressLint("SetJavaScriptEnabled")
    private fun loadThingSpeakChartTemperature() {
        webViewTemperature.settings.javaScriptEnabled = true
        webViewTemperature.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
            }
        }

        val channelId = "2234589"
        val chartUrl = "https://thingspeak.com/channels/$channelId/charts/1?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Temperature&type=line"

        webViewTemperature.loadUrl(chartUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun loadThingSpeakChartHumidity() {
        webViewHumidity.settings.javaScriptEnabled = true
        webViewHumidity.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
            }
        }

        val channelId = "2234589"
        val chartUrl = "https://thingspeak.com/channels/$channelId/charts/2?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Humidity&type=line"

        webViewHumidity.loadUrl(chartUrl)
    }


    private fun startAutoRefresh(
        textViewTemperature: TextView,
        textViewHumidity: TextView,
        textViewCreatedAt: TextView
    ) {
        thingSpeakApi.getLatestData().enqueue(object : Callback<ThingSpeakResponse> {
            override fun onResponse(
                call: Call<ThingSpeakResponse>,
                response: Response<ThingSpeakResponse>
            ) {
                if (response.isSuccessful) {
                    val thingSpeakResponse = response.body()
                    if (thingSpeakResponse != null) {
                        val feeds = thingSpeakResponse.feeds
                        val latestFeed = feeds.firstOrNull() // Get the first feed if available

                        if (latestFeed != null) {
                            val temperature = latestFeed.field1
                            val humidity = latestFeed.field2
                            val createdAt = latestFeed.created_at

                            val localCreatedAt = convertUtcToLocalTime(createdAt)

                            textViewTemperature.text = "Temperature: $temperature °C"
                            textViewHumidity.text = "Humidity: $humidity %"
                            textViewCreatedAt.text = "Created At: $localCreatedAt"
                        } else {
                            textViewTemperature.text = "Temperature: N/A"
                            textViewHumidity.text = "Humidity: N/A"
                            textViewCreatedAt.text = "Created At: N/A"
                        }
                    } else {
                        textViewTemperature.text = "Temperature: N/A"
                        textViewHumidity.text = "Humidity: N/A"
                        textViewCreatedAt.text = "Created At: N/A"
                    }
                } else {
                    textViewTemperature.text = "Temperature: N/A"
                    textViewHumidity.text = "Humidity: N/A"
                    textViewCreatedAt.text = "Created At: N/A"
                }

                handler.postDelayed({
                    startAutoRefresh(textViewTemperature, textViewHumidity, textViewCreatedAt)
                }, refreshIntervalMillis)
            }

            override fun onFailure(call: Call<ThingSpeakResponse>, t: Throwable) {
                textViewTemperature.text = "Temperature: N/A"
                textViewHumidity.text = "Humidity: N/A"
                textViewCreatedAt.text = "Created At: N/A"

                handler.postDelayed({
                    startAutoRefresh(textViewTemperature, textViewHumidity, textViewCreatedAt)
                }, refreshIntervalMillis)
            }
        })
    }


    private fun convertUtcToLocalTime(utcTime: String): String {
        val utcDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        val localDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        utcDateFormat.timeZone = TimeZone.getTimeZone("UST")

        try {
            val date = utcDateFormat.parse(utcTime)
            return localDateFormat.format(date)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return ""
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}