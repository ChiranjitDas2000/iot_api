package com.example.weatherapp_01

data class Channel(
    val id: Int,
    val name: String,
    val latitude: String,
    val longitude: String,
    val field1: String,
    val field2: String,
    val created_at: String,
    val updated_at: String,
    val last_entry_id: Int
)

data class Feed(
    val created_at: String,
    val entry_id: Int,
    val field1: String,
    val field2: String
)

data class ThingSpeakResponse(
    val channel: Channel,
    val feeds: List<Feed>
)

