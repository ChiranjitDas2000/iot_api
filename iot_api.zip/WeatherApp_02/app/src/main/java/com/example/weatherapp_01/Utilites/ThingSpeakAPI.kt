package com.example.weatherapp_01.Utilites
import com.example.weatherapp_01.ThingSpeakResponse
import retrofit2.Call
import retrofit2.http.GET

interface ThingSpeakApi {

    @GET("channels/2234589/feeds.json?results=1")
    fun getLatestData(): Call<ThingSpeakResponse>
}